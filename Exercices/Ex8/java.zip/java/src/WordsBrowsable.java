public interface WordsBrowsable {
    public void browse(WordsVisitor visitor);
}
