public interface WordsVisitor {
    public void visit(String word);
}
